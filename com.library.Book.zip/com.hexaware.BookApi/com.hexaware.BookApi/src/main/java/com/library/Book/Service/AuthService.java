package com.library.Book.Service;

import com.library.Book.Entity.SignupRequest;
import com.library.Book.Entity.User;

public interface AuthService {
	
	User createUser(SignupRequest signupRequest);
	
	boolean hasCustomerWithEmail(String Email);

}
