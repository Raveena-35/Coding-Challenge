package com.library.Book.Enum;

public enum UserRole {
	
	ADMIN,
	USER

}
